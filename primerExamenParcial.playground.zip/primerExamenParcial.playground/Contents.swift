import UIKit

var str = "Hello, playground"

var diceOne = Int(arc4random_uniform(6))
var diceTwo = Int(arc4random_uniform(6))

var dices = diceOne + diceTwo

class Animal{
    var position = 0
    func move() {
        position = position + dices
    }
    func sSCond() {
            switch position {
            case 8:
            position = position + 4
            case 20:
            position = position + 54
            case 32:
            position = position + 24
            case 40:
            position = position + 20
            case 76:
            position = position + 10
            case 90:
            position = position + 2
            case 96:
            position = position - 14
            case 84:
            position = position - 22
            case 66:
            position = position - 52
            case 58:
            position = position - 16
            case 22:
            position = position - 20
            case 30:
            position = position - 14
            case 100:
            print("Sayonara")
            default:
            position = position + 0
            }
    }
}


class tortuga : Animal{
    
}

class liebre : Animal{
    override func move() {
        switch dices {
        case 6, 7, 8:
            position = position + 0
        case 2, 3:
            position = position + (dices*2)
        case 12:
            position = position + 15
        default:
            position = position + dices
        }
    }
}

