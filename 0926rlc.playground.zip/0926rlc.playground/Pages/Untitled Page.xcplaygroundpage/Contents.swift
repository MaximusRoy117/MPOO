import UIKit

var str = "Hello, playground"

enum CompassPoint{
    case north
    case south
    case east
    case west
}

//var compassHeading = CompassPoint.west

let compassHeading: CompassPoint = .west

switch compassHeading {
case .north:
    print("I'm heading North")
case .east:
    print("I'm heading East")
case .west:
    print("I'm heading West")
case .south:
    print("I'm heading South")
}

struct Movie {
    var name: String
    var releaseYear: Int
    var genere: Genere
}

enum Genere {
    case animated, action, romance, documentary, biography, thriller
}

let movie = Movie (name: "Finding Dory", releaseYear: 2016, genere: .animated)



