import UIKit

var str = "Hello, playground"

class Vehiculo {
    var capacidad = 0
    var birlos:Int
    
    init(birlos:Int){
        self.birlos=birlos
    }
    
    func actividad(){
        print("Hago algo")
    }
}

class Terrestres: Vehiculo{
    var ruedas = 1
}

class Coche: Terrestres{
    var puertas = 2
    override func actividad() {
        print("Corro rapido")
        self.puertas=4
    }
}

let mustang = Coche(birlos: 4)
let bestia = Terrestres(birlos: 3)

mustang.puertas=4
mustang.capacidad=500
mustang.actividad()
//bestia.actividad()
