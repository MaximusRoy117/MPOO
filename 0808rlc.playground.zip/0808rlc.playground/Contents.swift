import UIKit

var str = "Hello, playground";

print(str);

2+2;

print(2+2);

let nombre = "julio";

let pi = 3.1416;

var edad = 15;

edad = 25;

print(edad);

print(nombre);

let mañana = "viérnes";

print(mañana);

/*let userName = "julio"
let userAge = "31"
let userDel = "alvaro Obregon"*/

let myVar = "variable de ejemplo";

//this is a comment

//this is one more pointless comment

let movieName = "The lion king";
let movieYear = 2019;
let movieDirector = "Dato desconocido";

let addOne = 1;
let addTwo: Int;
let addThree: Double;
let addFour = 1.50;

addTwo = 7;

let playerName = "Rodrigo";
let playerScore = 3000;
//playerScore = playerName;

var cocienteScore:Double = 23;
//cocienteScore = 22.55;
print(cocienteScore);

var jota = "";
jota = "letra j";

var ese:Character = "s";

//ese = "mi ese";

var x:Int;

x=10;

print(x);

struct Car {
    let brand:String;
    let model:String;
    let year:Int;
}

Car.init(brand:"Cadillac", model:"1991", year:2020);
