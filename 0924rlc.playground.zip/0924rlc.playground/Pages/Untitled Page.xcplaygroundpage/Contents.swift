import UIKit

var str = "Hello, playground"

var nombre:String?

nombre=nil
nombre="Adrian"

print(nombre!)

if nombre != nil{
    print(nombre!)
}

if let nombre = nombre{
    print(nombre)
}

print(nombre!)

func divide (_ number: Double, by divisor: Double){
    if divisor != 0.0 {
        let result = number/divisor
        print(result)
    }
}

divide(10.0, by: 5.0)

func divideGuard (_ number: Double, by divisor: Double){
    guard divisor != 0.0 else{return}
    
    let result = number/divisor
    print(result)
}


divideGuard(10.0, by: 2.0)

var edad:Int?

func edadPapa(){
    guard let edad = edad else {return}
    print(edad)
}

edadPapa()
