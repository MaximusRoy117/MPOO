//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

var nombre:String?
var apellido:String?
var estatura:Double?
var peso:Int?
var debut:Int?

nombre="Kemonito"
apellido=""
estatura=0.8
peso=45
debut=1988

func presenta(){
    guard let nombre = nombre else {return}
    guard let apellido = apellido else {return}
    guard let estatura = estatura else {return}
    guard let peso = peso else {return}
    guard let debut = debut else {return}
    print("\(nombre) \(apellido), with \(estatura) m and \(peso) kg, debuted on \(debut)")
}

presenta()

//: [Next](@next)
