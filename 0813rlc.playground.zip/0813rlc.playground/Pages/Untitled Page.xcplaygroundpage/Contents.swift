import UIKit

var str = "Hello, playground"

var favouritePerson = "MyMom";

var shoeNumb = 6.5;

shoeNumb = 10;

favouritePerson = "myHomie";

var enemyScore = 3 * 8;

var myScore = 100 / 4;

var totalScore = enemyScore + myScore;

let totalDistance = 2.5;

var acomDistance = 1.7;

var missDistance = totalDistance - acomDistance;

print(missDistance);

let x:Double = 51;
let y:Double = 4;
let z = x / y;

print(z)

myScore = 10;

myScore = myScore + 1;

myScore += 1;
myScore -= 2;

myScore *= 2;
myScore /= 10;

var a = 2;
var b = 3;
var c = 5;

print(a+b*c);
print((a+b)*c);

let d = 3;
let e = 0.1416;
let pi = Double(d) + e;

let f = 10;
let g = 3;

let h = Double(f)/Double(g);

print(h);
