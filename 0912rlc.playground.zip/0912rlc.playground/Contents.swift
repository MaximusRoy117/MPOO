import UIKit

var str = "Hello, playground"

struct Book {
    let name:String
    let publicationYear:Int?
}

let firstHarryPotter=Book(name: "Harry Potter and the Sorcerer's Stone", publicationYear: 1997)

let secondHarryPotter=Book(name: "Harry Potter and the Chamber of Secrets", publicationYear: 1998)

let holyBible=Book(name: "Holy Bible", publicationYear: nil)

/*print(holyBible.publicationYear)

if holyBible.publicationYear != nil{
    print(holyBible.publicationYear)
}else{
    print("No publication date")
}*/

//print(holyBible.publicationYear!)

//let number:Int = nil

if let publication=holyBible.publicationYear{
    print(publication)
}

let var1:Int?

var1 = 2

if var var1=var1{
    print(var1)
    var1=5
    print(var1)
}

print(var1!)

struct Toddler {
    var birthName:String
    var monthsOld:Int
    
    init?(birthName:String, monthsOld:Int) {
        if monthsOld < 12 || monthsOld > 36{
            return nil
        }else{
            self.birthName=birthName
            self.monthsOld=monthsOld
        }
    }
}

let possibleToddler = Toddler(birthName: "Frida Sofia", monthsOld: 9)

if let toddler = possibleToddler{
    print("\(toddler.birthName) is \(toddler.monthsOld)")
}else{
    print("not existent")
}
