import UIKit

var str = "Hello, playground"

struct host {
    var hostName: String
    var hostPhone: Int
    var room: Room
    var hostNum: Int
    var nights:  Int
    
    func printBill(){
        var pricebeta: Int
        switch hostOne.room {
        case .junior:
            pricebeta=200*(hostOne.hostNum*hostOne.nights)
        case .gold:
            pricebeta=400*(hostOne.hostNum*hostOne.nights)
        case .platinum:
            pricebeta=600*(hostOne.hostNum*hostOne.nights)
        case .diamond:
            pricebeta=1000*(hostOne.hostNum*hostOne.nights)
        }
        print("Client: \(hostOne.hostName) \n Phone number: \(hostOne.hostPhone) \n Room: \(hostOne.room) \n Hosts: \(hostOne.hostNum) \n Nights: \(hostOne.nights) \n Bill: $ \(pricebeta) USD")
    }
}

enum Room {
    case junior, gold, platinum, diamond
}

let hostOne = host(hostName: "Maximus", hostPhone: 5524976002, room: .diamond, hostNum: 2, nights: 5)

hostOne.printBill()
