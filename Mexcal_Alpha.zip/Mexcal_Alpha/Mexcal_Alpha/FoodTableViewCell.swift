//
//  FoodTableViewCell.swift
//  Mexcal_Alpha
//
//  Created by 2020-1 on 11/22/19.
//  Copyright © 2019 Lopez&Paniagua. All rights reserved.
//

import UIKit

class FoodTableViewCell: UITableViewCell {


    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
