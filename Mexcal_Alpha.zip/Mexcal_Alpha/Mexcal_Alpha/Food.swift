//
//  Food.swift
//  Mexcal_Alpha
//
//  Created by 2020-1 on 11/22/19.
//  Copyright © 2019 Lopez&Paniagua. All rights reserved.
//

import Foundation
import UIKit

struct Food {
    let name:String?
    let calories:String?
    let image:String?
}
